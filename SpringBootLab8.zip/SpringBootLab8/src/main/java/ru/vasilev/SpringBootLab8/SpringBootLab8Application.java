package ru.vasilev.SpringBootLab8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLab8Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLab8Application.class, args);
	}

}
