package ru.vasilev.SpringBootLab8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLab8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
